package com.smartbuild;

public class App {
    public static void main(String[] args) {
        ProjectManager pm = new ProjectManager();
        pm.listTasks();
    }
}
