package com.smartbuild;

public class ProjectManager {
    public void listTasks() {
        System.out.println("• Tarea 1: Modelar IA");
        System.out.println("• Tarea 2: Entrenar modelo");
        System.out.println("• Tarea 3: Implementar API");
    }
}
